package com.vertimail.android.di

import android.content.Context
import com.vertimail.android.AppPreferences
import com.vertimail.android.data.api.ApiService
import com.vertimail.android.data.api.FakeApiService
import com.vertimail.android.data.api.RealApiService

/**
 * ServiceLocator : Pattern simple pour l'injection de dépendances
 *
 * Permet de basculer entre FakeApi (pour tests) et RealApi (production)
 */
object ServiceLocator {
    private const val USE_FAKE_API = false

    private var cachedBaseUrl: String? = null
    private var cachedRealApi: RealApiService? = null

    fun apiService(context: Context): ApiService {
        if (USE_FAKE_API) return FakeApiService()

        val baseUrl = AppPreferences(context).getServerBaseUrl()

        if (cachedRealApi == null || cachedBaseUrl != baseUrl) {
            cachedBaseUrl = baseUrl
            cachedRealApi = RealApiService(baseUrl)
        }
        return cachedRealApi!!
    }
}
