package com.vertimail.android

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.vertimail.android.data.api.FakeApiService
import com.vertimail.android.data.api.ApiResult
import com.vertimail.android.di.ServiceLocator

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val prefs = AppPreferences(this)
        val api = ServiceLocator.apiService(this)



        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            tvStatus.text = "Connexion..."

            Thread {
                val result = api.login(username, password)

                runOnUiThread {
                    when (result) {
                        is ApiResult.Success -> {
                            prefs.setAuthToken(result.data.token)
                            tvStatus.text = "Connecté ✅"
                            startActivity(Intent(this, AuthSendActivity::class.java))
                        }
                        is ApiResult.Error -> {
                            prefs.setAuthToken(null)
                            tvStatus.text = "Erreur: ${result.message}"
                        }
                    }
                }
            }.start()
        }

    }
}
