package com.vertimail.android.data.api

sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

data class LoginResponse(val token: String)

interface ApiService {
    fun login(username: String, password: String): ApiResult<LoginResponse>
    fun sendMail(token: String, to: String, subject: String, content: String): ApiResult<Unit>
    fun checkNew(token: String): ApiResult<List<MailHeader>>
}

data class MailHeader(
    val id: String,
    val from: String,
    val subject: String
)
