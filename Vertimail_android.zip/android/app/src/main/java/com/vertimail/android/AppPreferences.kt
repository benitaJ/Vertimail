package com.vertimail.android

import android.content.Context

class AppPreferences(context: Context) {


    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAuthToken(): String? = prefs.getString(KEY_AUTH_TOKEN, null)

    fun setAuthToken(value: String?) {
        if (value == null) prefs.edit().remove(KEY_AUTH_TOKEN).apply()
        else prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()
    }

    fun getServerBaseUrl(): String =
        prefs.getString(KEY_BASE_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL

    fun setServerBaseUrl(value: String) {
        prefs.edit().putString(KEY_BASE_URL, value).apply()
    }

    fun getUdpHost(): String =
        prefs.getString(KEY_UDP_HOST, DEFAULT_UDP_HOST) ?: DEFAULT_UDP_HOST

    fun setUdpHost(value: String) {
        prefs.edit().putString(KEY_UDP_HOST, value).apply()
    }

    fun getUdpPort(): Int =
        prefs.getInt(KEY_UDP_PORT, DEFAULT_UDP_PORT)

    fun setUdpPort(value: Int) {
        prefs.edit().putInt(KEY_UDP_PORT, value).apply()
    }

    companion object {
        private const val PREFS_NAME = "vertimail_prefs"
        private const val KEY_BASE_URL = "server_base_url"
        private const val KEY_UDP_HOST = "udp_host"
        private const val KEY_UDP_PORT = "udp_port"
        private const val KEY_AUTH_TOKEN = "auth_token"

        private const val DEFAULT_BASE_URL = "http://192.168.1.10:8080"
        private const val DEFAULT_UDP_HOST = "192.168.1.10"
        private const val DEFAULT_UDP_PORT = 12345
    }
}
