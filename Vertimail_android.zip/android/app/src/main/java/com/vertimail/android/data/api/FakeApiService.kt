package com.vertimail.android.data.api

class FakeApiService : ApiService {

    override fun login(username: String, password: String): ApiResult<LoginResponse> {
        if (username.isBlank() || password.isBlank()) {
            return ApiResult.Error("Champs vides")
        }

        // Mock : accepte un compte "demo/demo" et refuse le reste (simple à tester)
        return if (username == "demo" && password == "demo") {
            ApiResult.Success(LoginResponse(token = "fake-token-123"))
        } else {
            ApiResult.Error("Identifiants incorrects (essaie demo / demo)")
        }
    }

    override fun sendMail(token: String, to: String, subject: String, content: String): ApiResult<Unit> {
        if (token.isBlank()) return ApiResult.Error("Non authentifié")
        if (to.isBlank()) return ApiResult.Error("Destinataire vide")
        if (subject.isBlank()) return ApiResult.Error("Sujet vide")
        if (content.isBlank()) return ApiResult.Error("Contenu vide")

        // Mock : succès direct
        return ApiResult.Success(Unit)
    }

    override fun checkNew(token: String): ApiResult<List<MailHeader>> {
        if (token.isBlank()) return ApiResult.Error("Non authentifié")

        // Mock : 1 "nouveau mail" de temps en temps pour tester les notifications plus tard
        val fakeList = listOf(
            MailHeader(id = "1", from = "teacher@univ.test", subject = "Bienvenue sur Vertimail")
        )
        return ApiResult.Success(fakeList)
    }
}
