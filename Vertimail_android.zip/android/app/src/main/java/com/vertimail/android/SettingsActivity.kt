package com.vertimail.android

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = AppPreferences(this)

        val etBaseUrl = findViewById<EditText>(R.id.etBaseUrl)
        val etUdpHost = findViewById<EditText>(R.id.etUdpHost)
        val etUdpPort = findViewById<EditText>(R.id.etUdpPort)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        // Pré-remplir
        etBaseUrl.setText(prefs.getServerBaseUrl())
        etUdpHost.setText(prefs.getUdpHost())
        etUdpPort.setText(prefs.getUdpPort().toString())

        btnSave.setOnClickListener {
            val baseUrl = etBaseUrl.text.toString().trim()
            val udpHost = etUdpHost.text.toString().trim()
            val udpPortStr = etUdpPort.text.toString().trim()

            if (baseUrl.isEmpty()) {
                tvStatus.text = "Erreur: Base URL vide"
                return@setOnClickListener
            }
            if (!baseUrl.startsWith("http://") && !baseUrl.startsWith("https://")) {
                tvStatus.text = "Erreur: Base URL doit commencer par http:// ou https://"
                return@setOnClickListener
            }
            if (udpHost.isEmpty()) {
                tvStatus.text = "Erreur: UDP Host vide"
                return@setOnClickListener
            }

            val udpPort = udpPortStr.toIntOrNull()
            if (udpPort == null || udpPort !in 1..65535) {
                tvStatus.text = "Erreur: UDP Port invalide (1..65535)"
                return@setOnClickListener
            }

            prefs.setServerBaseUrl(baseUrl)
            prefs.setUdpHost(udpHost)
            prefs.setUdpPort(udpPort)

            tvStatus.text = "Sauvegardé ✅"
        }
    }
}
