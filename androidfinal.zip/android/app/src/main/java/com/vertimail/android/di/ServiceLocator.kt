package com.vertimail.android.di

import android.content.Context
import com.vertimail.android.AppPreferences
import com.vertimail.android.data.api.ApiService
import com.vertimail.android.data.api.FakeApiService
import com.vertimail.android.data.api.RealApiService

/**
 * ServiceLocator : Pattern simple pour l'injection de dépendances
 *
 * Permet de basculer entre FakeApi (pour tests) et RealApi (production)
 */
object ServiceLocator {

    // 🔴 CHANGE CETTE VALEUR À FALSE POUR UTILISER LE VRAI BACKEND
    private const val USE_FAKE_API = false

    /**
     * Fournit l'instance ApiService appropriée
     * @param context Nécessaire pour lire l'URL dans SharedPreferences
     */
    fun apiService(context: Context): ApiService {
        return if (USE_FAKE_API) {
            FakeApiService()
        } else {
            val prefs = AppPreferences(context)
            val baseUrl = prefs.getServerBaseUrl()
            RealApiService(baseUrl)
        }
    }
}