package com.vertimail.android.data.udp

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class UdpClient {

    fun sendMessage(
        udpHost: String,
        udpPort: Int,
        to: String,
        subject: String,
        content: String,
        timeoutMs: Int = 2000
    ): String {

        val payload = "$to\n$subject\n$content"
        val data = payload.toByteArray(Charsets.UTF_8)

        var socket: DatagramSocket? = null

        return try {
            val address = InetAddress.getByName(udpHost)

            socket = DatagramSocket()
            socket.soTimeout = timeoutMs

            // Envoi
            socket.send(DatagramPacket(data, data.size, address, udpPort))

            // Attente ACK
            val buffer = ByteArray(1024)
            val responsePacket = DatagramPacket(buffer, buffer.size)
            socket.receive(responsePacket)

            val response = String(responsePacket.data, 0, responsePacket.length, Charsets.UTF_8).trim()
            if (response.isEmpty()) "OK (réponse vide)" else "OK: $response"
        } catch (e: java.net.SocketTimeoutException) {
            "Timeout: pas de réponse du serveur"
        } catch (e: Exception) {
            "Erreur réseau: ${e.message ?: "unknown"}"
        } finally {
            socket?.close()
        }
    }
}
