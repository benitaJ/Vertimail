package com.vertimail.android

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.vertimail.android.data.api.ApiResult
import com.vertimail.android.data.api.FakeApiService
import com.vertimail.android.di.ServiceLocator

class AuthSendActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth_send)

        val prefs = AppPreferences(this)
        val api = ServiceLocator.apiService(this)


        val etTo = findViewById<EditText>(R.id.etTo)
        val etSubject = findViewById<EditText>(R.id.etSubject)
        val etContent = findViewById<EditText>(R.id.etContent)
        val btnSend = findViewById<Button>(R.id.btnSend)
        val btnLogout = findViewById<Button>(R.id.btnLogout)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        val token = prefs.getAuthToken()
        if (token.isNullOrBlank()) {
            // sécurité: si pas connecté, retour login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        btnSend.setOnClickListener {
            val to = etTo.text.toString().trim()
            val subject = etSubject.text.toString().trim()
            val content = etContent.text.toString().trim()

            tvStatus.text = "Envoi..."

            val result = api.sendMail(token, to, subject, content)
            when (result) {
                is ApiResult.Success -> tvStatus.text = "Envoyé ✅ (mock)"
                is ApiResult.Error -> tvStatus.text = "Erreur: ${result.message}"
            }
        }

        btnLogout.setOnClickListener {
            prefs.setAuthToken(null)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
