package com.vertimail.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.vertimail.android.work.CheckMailWorker
import java.util.concurrent.TimeUnit

class HomeActivity : AppCompatActivity() {

    // On garde une référence sur tvStatus, pour pouvoir l’utiliser dans le callback permission
    private lateinit var tvStatus: TextView

    // 1) Callback permission : si l'utilisateur accepte, on démarre immédiatement
    private val requestNotifPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startNotifications()
            } else {
                tvStatus.text = "Permission notifications refusée"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // 2) Récupérer toutes les vues
        val btnAnonymousUdp = findViewById<Button>(R.id.btnAnonymousUdp)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnEnableNotifications = findViewById<Button>(R.id.btnEnableNotifications)
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        tvStatus = findViewById(R.id.tvStatus)

        // 3) Navigation
        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        btnAnonymousUdp.setOnClickListener {
            startActivity(Intent(this, UdpSendActivity::class.java))
        }

        btnLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        // 4) Notifications (WorkManager)
        btnEnableNotifications.setOnClickListener {

            // Android 13+ : demander permission
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

                if (!granted) {
                    tvStatus.text = "Demande permission notifications…"
                    requestNotifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    return@setOnClickListener
                }
            }

            // Si permission déjà OK (ou Android < 13), on lance direct
            startNotifications()
        }
    }

    private fun startNotifications() {
        // Worker périodique (min 15 min)
        val periodic = PeriodicWorkRequestBuilder<CheckMailWorker>(15, TimeUnit.MINUTES).build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodic
        )

        // Test immédiat (oneShot) pour voir une notif tout de suite
        val oneShot = OneTimeWorkRequestBuilder<CheckMailWorker>().build()
        WorkManager.getInstance(this).enqueue(oneShot)

        tvStatus.text = "Notifications activées ✅ (test + check 15 min)"
    }

    companion object {
        private const val WORK_NAME = "check_mail_work"
    }
}
