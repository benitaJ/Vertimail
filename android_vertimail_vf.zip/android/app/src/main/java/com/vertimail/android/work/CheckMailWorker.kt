package com.vertimail.android.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.vertimail.android.AppPreferences
import com.vertimail.android.R
import com.vertimail.android.di.ServiceLocator
import com.vertimail.android.data.api.ApiResult

class CheckMailWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        android.util.Log.d("VERTIMAIL", "CheckMailWorker exécuté")
        val prefs = AppPreferences(applicationContext)
        val token = prefs.getAuthToken()

        // Si pas authentifiée, on ne notifie pas
        if (token.isNullOrBlank()) {
            return Result.success()
        }

        val api = ServiceLocator.apiService(applicationContext)
        val result = api.checkNew(token)

        return when (result) {
            is ApiResult.Success -> {
                val list = result.data
                if (list.isNotEmpty()) {
                    // Ici on notifie le 1er mail (simple). Plus tard, tu peux boucler.
                    val first = list.first()
                    showNotification(
                        from = first.from,
                        subject = first.subject,
                        url = prefs.getServerBaseUrl()
                    )
                }
                Result.success()
            }
            is ApiResult.Error -> {
                // En mock: on peut considérer "success" (pas de retry infini).
                Result.success()
            }
        }
    }

    private fun showNotification(from: String, subject: String, url: String) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Channel obligatoire Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Vertimail notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }

        // Clic -> ouvre le site web (baseUrl)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            0,
            intent,
            flags
        )

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // simple, existe déjà
            .setContentTitle(from) // expéditeur
            .setContentText(subject) // sujet
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        nm.notify(NOTIF_ID, notification)
    }

    companion object {
        private const val CHANNEL_ID = "vertimail_channel"
        private const val NOTIF_ID = 1001
    }
}
