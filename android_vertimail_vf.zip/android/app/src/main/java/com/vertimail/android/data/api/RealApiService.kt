package com.vertimail.android.data.api

import android.util.Log
import com.google.gson.Gson
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.time.LocalTime
/**
 * Implémentation réelle de l'ApiService qui communique avec le backend Vert.x
 *
 * ⚠️ IMPORTANT : Cette classe est appelée depuis des threads background
 * (Coroutines dans LoginActivity, WorkManager dans CheckMailWorker)
 * donc les appels synchrones (.execute()) sont OK.
 */
class RealApiService(private val baseUrl: String) : ApiService {

    companion object {
        private const val TAG = "RealApiService"
        private const val TIMEOUT_SECONDS = 15L
        private const val SESSION_COOKIE_NAME = "webmail_session"
    }

    // Stockage du cookie de session
    private var sessionCookie: String? = null

    // CookieJar personnalisé pour gérer les cookies de session
    private val cookieJar = object : CookieJar {
        private val cookieStore = mutableMapOf<String, List<Cookie>>()

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            Log.d(TAG, "Saving ${cookies.size} cookies for ${url.host}")
            cookieStore[url.host] = cookies

            // Stocker le cookie de session
            cookies.find { it.name == SESSION_COOKIE_NAME }?.let {
                sessionCookie = "${it.name}=${it.value}"
                Log.d(TAG, "Session cookie saved: $sessionCookie")
            }
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val cookies = cookieStore[url.host] ?: emptyList()
            Log.d(TAG, "Loading ${cookies.size} cookies for ${url.host}")
            return cookies
        }
    }

    // Client HTTP avec gestion des cookies
    private val client = OkHttpClient.Builder()
        .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .cookieJar(cookieJar)
        .followRedirects(false) // Ne pas suivre les redirections automatiquement
        .build()

    private val gson = Gson()

    /**
     * Authentification via POST /login
     * Le backend retourne un cookie de session dans Set-Cookie
     */
    override fun login(username: String, password: String): ApiResult<LoginResponse> {
        Log.d(TAG, "Attempting login for user: $username at $baseUrl/login")

        try {
            val formBody = FormBody.Builder()
                .add("username", username)
                .add("password", password)
                .build()

            val request = Request.Builder()
                .url("$baseUrl/login")
                .post(formBody)
                .build()

            client.newCall(request).execute().use { response ->
                Log.d(TAG, "Login response code: ${response.code}")

                when (response.code) {
                    302, 303 -> {
                        // Redirection = succès (le backend redirige vers /mail/inbox)
                        val location = response.header("Location")
                        Log.d(TAG, "Login successful, redirect to: $location")

                        return if (sessionCookie != null) {
                            Log.d(TAG, "Login OK, sessionCookie=$sessionCookie")
                            ApiResult.Success(LoginResponse(token = sessionCookie!!))
                        } else {
                            ApiResult.Error("Login réussi mais pas de cookie reçu")
                        }

                    }
                    200 -> {
                        // Succès direct (peu probable avec ce backend mais on gère)
                        return if (sessionCookie != null) {
                            ApiResult.Success(LoginResponse(token = sessionCookie!!))
                        } else {
                            ApiResult.Error("Login réussi mais pas de cookie reçu")
                        }
                    }
                    else -> {
                        // Échec (401, 403, 500, etc.)
                        return ApiResult.Error("Identifiants incorrects (code ${response.code})")
                    }
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error during login", e)
            return ApiResult.Error("Erreur réseau : ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during login", e)
            return ApiResult.Error("Erreur réseau : ${e}")
        }
    }

    /**
     * Envoi de mail via POST /mail/compose
     * Nécessite le cookie de session
     */
    override fun sendMail(
        token: String,
        to: String,
        subject: String,
        content: String
    ): ApiResult<Unit> {
        Log.d(TAG, "Sending mail to: $to")
        Log.d(TAG, "Before sendMail: sessionCookie=$sessionCookie tokenParam=$token baseUrl=$baseUrl")

        try {
            val formBody = FormBody.Builder()
                .add("to", to)
                .add("subject", subject)
                .add("content", content)
                .add("action", "send") // "send" ou "draft"
                .build()

            val request = Request.Builder()
                .url("$baseUrl/mail/compose")
                .header("Cookie", token)
                .post(formBody)
                .build()

            client.newCall(request).execute().use { response ->
                Log.d(TAG, "Send mail response code=${response.code}, location=${response.header("Location")}")


                return when (response.code) {
                    302, 303 -> {
                        // Redirection = succès
                        ApiResult.Success(Unit)
                    }
                    200 -> {
                        ApiResult.Success(Unit)
                    }
                    401, 403 -> {
                        ApiResult.Error("Session expirée, reconnectez-vous")
                    }
                    else -> {
                        ApiResult.Error("Échec de l'envoi (code ${response.code})")
                    }
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error sending mail", e)
            return ApiResult.Error("Erreur réseau : ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error sending mail", e)
            return ApiResult.Error("Erreur : ${e.message}")
        }
    }

    /**
     * ⚠️ LIMITATION : Le backend n'a pas de route API dédiée pour "checkNew"
     *
     * SOLUTION TEMPORAIRE :
     * On fait un GET sur /mail/inbox et on regarde si la réponse est 200.
     * Si oui, on retourne une liste vide (pas de nouveaux mails détectés).
     *
     * SOLUTION IDÉALE (à faire côté backend) :
     * Ajouter une route GET /api/mail/new qui retourne du JSON :
     * [{"id": "...", "from": "...", "subject": "..."}]
     */
    override fun checkNew(token: String): ApiResult<List<MailHeader>> {
        Log.d(TAG, "Checking for new mails via /api/mail/new")

        try {
            val request = Request.Builder()
                .url("$baseUrl/api/mail/new") // Nouvelle route
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                Log.d(TAG, "Check new response code: ${response.code}")

                return when (response.code) {
                    200 -> {
                        val body = response.body?.string() ?: "[]"
                        Log.d(TAG, "Response body: $body")

                        try {
                            val mails = gson.fromJson(body, Array<MailHeader>::class.java).toList()
                            Log.d(TAG, "Parsed ${mails.size} mails")
                            ApiResult.Success(mails)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing JSON", e)
                            ApiResult.Success(emptyList())
                        }
                    }
                    401, 403 -> {
                        ApiResult.Error("Session expirée")
                    }
                    else -> {
                        ApiResult.Error("Erreur (code ${response.code})")
                    }
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "Network error", e)
            return ApiResult.Error("Erreur réseau : ${e.message}")
        }
    }
}