package com.vertimail.android

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.vertimail.android.data.udp.UdpClient

class UdpSendActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_udp_send)

        val prefs = AppPreferences(this)
        val udpClient = UdpClient()

        val etTo = findViewById<EditText>(R.id.etTo)
        val etSubject = findViewById<EditText>(R.id.etSubject)
        val etContent = findViewById<EditText>(R.id.etContent)
        val btnSend = findViewById<Button>(R.id.btnSend)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        btnSend.setOnClickListener {
            val to = etTo.text.toString().trim()
            val subject = etSubject.text.toString().trim()
            val content = etContent.text.toString().trim()

            tvStatus.text = "Envoi..."

            val host = prefs.getUdpHost()
            val port = prefs.getUdpPort()

            Thread {
                val result = udpClient.sendMessage(
                    udpHost = host,
                    udpPort = port,
                    to = to,
                    subject = subject,
                    content = content
                )
                runOnUiThread { tvStatus.text = result }
            }.start()
        }
    }
}
